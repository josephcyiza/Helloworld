package com.JosephFile.swingapp.LibraryManagementSystem.model;

public enum Status {
    CHECK_IN, CHECK_OUT
}
