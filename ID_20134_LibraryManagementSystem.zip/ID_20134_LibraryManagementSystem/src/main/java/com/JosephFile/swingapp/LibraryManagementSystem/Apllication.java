package com.JosephFile.swingapp.LibraryManagementSystem;

import com.elvis.swingapp.librarysystem.view.MainView;

public class Apllication {
   
    public static void main(String[] args) {
        MainView mainView = new MainView();
        mainView.setVisible(true);
    }
}
