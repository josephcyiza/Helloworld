package com.JosephFile.swingapp.LibraryManagementSystem.utils;

public class GeneralUtility {
    
    public static String[] StringSplit(String property){
        String[] parStrings = property.split(" ");
        return parStrings;
    }
}
